# SSAFY 교육생을 위한 Vue.js 예제

- 작성자 : 이지우

## 과제 목표
- 현업 개발자 코드 읽어보기   

## 실습 과제
1. 프로젝트 구조 파악하기

2. UI / UX 분석
	- 핵심 기능이 아닌 UI/UX를 위한 구현 파악
	- 더 좋은 방법 고민해보기
	- 추가 필요한 UX 찾아보기

3. 재생 목록 편집 기능 구현
    - 기본 구현
	    - 재생 목록에 음악 추가
	    - 재생 목록에서 음악 삭제

    - 심화 과제
	    - 새 재생 목록 만들기
	    - 음악 재생 -> 정지 시 MusicWave 멈추기

    - 제출 방법
    	- README.md 파일에 정리하기

4. 도전 과제
    - 나만의 애니메이션 만들어 보기

    - 제출 방법
	    - 오후 강의 30분 전까지 반 담당 컨설턴트님께 작성한 애니메이션의 .vue + scss 파일 MM으로 공유
	    
	- 제출 기한
	    - ~13:40까지 제출
	    
	- 오후 방송(14:00 ~ )에서 제출 작품 살펴보고 3개 작품에 시상
<br>

## Api 명세서 (더미 데이터 기반)

#### Model 정의    

- playList 			// 재생 목록
```
{
	"id": 101,
	"name": "재생 목록 이름",
	"isEditable": true,  // 재생 목록 편집 가능 여부
}
```
- musicItem 		// 음악 정보
```
{
	"index": 0,
	"title": "음악 제목",
	"artist": "가수",
	"album": "앨범명",
	"imgName": "앨범 아트 파일명",
	"ranking": 1   // 차트 순위
}
```
#### Data 구조 정의    
- playListArray  : [{ playList }, { playList }, { playList } ... ]
- musicList      : [{ musicItem }, { musicItem }, { musicItem } ... ]
- myMusicList    : [{ playList, musicList }, { playList, musicList }, { playList, musicList } ... ]

#### Api 결과 값 예시   
```
{
	"isSuccess": true,    // 성공 여부
	"data": {             // 결과 데이터
		"playList": [
			{
				"id": 0,
				"name": '인기뮤직',
				"isEditable": false,
			},
			{
				"id": 101,
				"name": "Top 10",
				"isEditable": true,
			},
			{
				"id": 102,
				"name": "내 재생 목록 A",
				"isEditable": true,
			},
		]
	}
}
```

#### API   
- 선택한 음악이 포함되어 있는 재생목록 배열 반환 API
```
MainApi.contains(musicItem);
return -> playListArray
```

- 선택한 음악을 재생목록에 추가/삭제 API
```
MainApi.addToPlayList(playListId, musicItem);
return -> 추가 완료: true / 삭제 완료: false
```

- 해당 재생 목록의 음악들 불러오기 API
```
MainApi.getMusicList(playListId);
return -> MusicList
```

