<template>
  <div class="app-wrap">
    <router-view/>    
  </div>
</template>

<script>
import "./assets/style/index.scss";

export default {
  components: {
  }
}
</script>