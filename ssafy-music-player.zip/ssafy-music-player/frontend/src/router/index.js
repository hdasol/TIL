import { createRouter, createWebHistory } from 'vue-router'
import Main from '@/views/main/Main.vue'
import Animation from '@/views/examples/animation/Animation.vue'
import SfcExample from '@/views/examples/singleFileComponent/SfcExample.vue'

const routes = [
  {
    path: '/',
    name: 'Main',
    component: Main
  },
  {
    path: '/ani',
    name: 'Animation',
    component: Animation
  },
  {
    path: '/sfc',
    name: 'SfcExample',
    component: SfcExample
  },
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
