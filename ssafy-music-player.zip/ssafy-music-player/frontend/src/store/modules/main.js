export default {
    namespaced: true,
    state: () => ({
        musicList: [],
        currentMusic: { 
          index: -1,
          title: "",
          artist: "",
          album: "",
          imgName: "music_album_art (0)",
          ranking: 0
				},
        musicColor: { hex : '#396afc', rgb : [57,106,252] },
        musicListElement: {}, // 스크립트로 스크롤 하기 위해
        playList: [],
        selectedPlayList: {},
    }),
    mutations: {
      setMusicList(state, payload) {
        state.musicList = payload;
        // 배열 상태 변화 감지 위해
        state.musicList.push({});
        state.musicList.pop();
      },
      setCurrentMusic(state, payload) {
        state.currentMusic = payload;
      },
      nextMusic(state, isNext) {
        let index = state.currentMusic.index;
        // 이전 / 다음 재생
        index = isNext ? index += 1 : index -= 1;

        // 현재 음악 처음 또는 끝에 트랙일 경우
        if (index >= state.musicList.length) {
          index = 0;
        } else if (index < 0) {
          index = state.musicList.length-1;
        }
        state.currentMusic = state.musicList[index];
      },
      setMusicListElement(state, payload) {
        state.musicListElement = payload;
      },
      scrollToMusicItem(state, payload) {
        state.musicListElement.scrollTop = payload;
      },
      setMusicColor(state, payload) {
        state.musicColor = payload;
      },
      setPlayList(state, payload) {
        state.playList = payload;
      },
      setSelectedPlayList(state, payload) {
        state.selectedPlayList = payload;
      },
    },
    actions: {
      
    },
    getters: {
      // 음악 선택 (재생) 여부 -> 음악 컨트롤러 표시
      isSelected: (state) => {
        return state.currentMusic.title !== '';
      },
    }
}