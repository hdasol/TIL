export default {
	namespaced: true,
	state: () => ({
		count: 0,
	}),
	mutations: {
		increment(state, payload = 1) {
			state.count += payload;
		}
	},
	actions: {
		
	},
	getters: {
	}
}