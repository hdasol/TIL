export default {
	namespaced: true,
	state: () => ({
			selectedMusic: '',
	}),
	mutations: {
		selectMusic(state, payload) {
			state.selectedMusic = payload;
		}
	},
	actions: {
		
	},
	getters: {
		// 플레이 리스트 편집 팝업 여부
		isVisible: (state) => {
			return state.selectedMusic !== '';
		}
	}
}