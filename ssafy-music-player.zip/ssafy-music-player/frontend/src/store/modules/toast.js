export default {
	namespaced: true,
	state: () => ({
			message: '',
	}),
	mutations: {
		showToast(state, payload) {
			state.message = payload;
		}
	},
	actions: {
		
	},
	getters: {
		isVisible: (state) => {
			return state.message !== '';
		}
	}
}