import { createStore } from 'vuex'
import main from './modules/main.js'
import examples from './modules/examples.js'
import playListEditor from './modules/playListEditor.js'
import toast from './modules/toast.js'

export default createStore({
  state: {
  },
  mutations: {
  },
  actions: {
  },
  modules: {
    main,
    examples,
    playListEditor,
    toast,
  }
})
