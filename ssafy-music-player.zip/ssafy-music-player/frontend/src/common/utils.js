import ColorThief from 'colorthief'

export default {
	// 이미지로부터 평균 색상을 추출하는 ColorThief Lib
	getImageColor(img) {
		let colorThief = new ColorThief();
		let rgbColor = colorThief.getColor(img);
		let hexColor = "#" + this.componentToHex(rgbColor[0]) + this.componentToHex(rgbColor[1]) + this.componentToHex(rgbColor[2]);
		return { hex : hexColor, rgb : rgbColor };
	},
	// rgb -> hex
	componentToHex(c) {
		var hex = c.toString(16);
		return hex.length == 1 ? "0" + hex : hex;
	},
	// 색상의 밝기 가져오기 
	getBrightness(rgb) {
		// http://www.w3.org/TR/AERT#color-contrast
		const brightness = Math.round(((parseInt(rgb[0]) * 299) +
												(parseInt(rgb[1]) * 587) +
												(parseInt(rgb[2]) * 114)) / 1000);
		return brightness;
	},
	// 색상의 밝기에 따라 Text color 결정
	getColorByBrightness(rgb) {
		const brightness = this.getBrightness(rgb);
		const textColor = (brightness > 125) ? 'black' : 'white';
		return textColor;
	},
	getImagePath(imgName, is2020 = true) {
		if (is2020) {
      return require('@/assets/image/m2020/' + imgName +'.png');
		} else {
      return require('@/assets/image/m2021/' + imgName +'.png');
		}
	},
  // 자연수인지
  isNaturalNumber(number) {
    let regExp = /^\d*$/;
    return regExp.test(String(number));
  },
  // 정수형인지
  isInteger(number) {
    let regExp = /^[+-]?\d*$/;
    return regExp.test(String(number));
  },
  // 실수형 (소숫점) 인지
  isDouble(number) {
    let regExp = /^[+-]?\d*(\.?\d*)$/;
    return regExp.test(String(number));
  },
  // 숫자 (소수점 포함) 인지
  isNumber(number) {
    let regExp = /^[-]?\d+(?:[.]\d+)?$/;
    return regExp.test(number);
  },
  // 휴대폰 번호
  isPhone(number) {
    let regExp = /^\d{3}-\d{3,4}-\d{4}$/;
    let regExp2 = /^\d{3}\d{3,4}\d{4}$/;
    return regExp.test(number) || regExp2.test(number);
  },
  // 비밀번호
  isPasswd(passwd) {
    let pw = passwd;
    let num = pw.search(/[0-9]/g);
    let eng = pw.search(/[a-z]/ig);
    let spe = pw.search(/[`~!@@#$%^&*|₩₩₩'₩";:₩/?]/gi);

    if(pw.length < 8 || pw.length > 20){
      return false;
    }
    // 공백 체크
    if(pw.search(/₩s/) != -1){
      return false;
    }
    // 영문/숫자/특수문자 중 택2
    if ( (num < 0 && eng < 0) || (eng < 0 && spe < 0) || (spe < 0 && num < 0) ){
      return false;
    }
    return true;
  },
}