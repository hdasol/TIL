export default {
	getPlayList() {
		let playlist = [];
		this.myMusicList.forEach(element => {
			playlist.push(element.playList);
		});
		return {
      "isSuccess": true,
      "data": {
				"playList": playlist,
			}
		}
	},
	getMusicList(playListId = 0) {
		let myMusic = this.myMusicList;
		let selectedList = [];

		myMusic.forEach(list => {
			if (Number(list.playList.id) === Number(playListId)) {
				selectedList = list
			}
		});
		return {
			"isSuccess": true,
			"data": {
				"musicList": selectedList
			}
		};
	},
	getMyMusicList() {
		return {
			"isSuccess": true,
			"data": {
				"myMusicList" : this.myMusicList 
			}
		}
	},
	myMusicList : [
		{
			"playList": {
				"id": 0,
				"name": '인기차트',
				"isEditable": false,
			},
			"musicList": [
				{ "index": 0,
				"title": "METEOR",
				"artist": "창모 (CHANGMO)",
				"album": "Boyhood",
				"imgName": "music_album_art (1)",
				"ranking": 1
				},
				{ "index": 1,
				"title": "Blueming",
				"artist": "아이유 (IU)",
				"album": "Love poem",
				"imgName": "music_album_art (2)",
				"ranking": 2
				},
				{ "index": 2,
				"title": "아무노래",
				"artist": "지코 (ZICO)",
				"album": "아무노래",
				"imgName": "music_album_art (3)",
				"ranking": 3
				},
				{ "index": 3,
				"title": "흔들리는 꽃들 속에서 네 샴푸향이 느껴진거야",
				"artist": "장범준",
				"album": "멜로가 체질 OST Part 3 (JTBC 금토 드라마)",
				"imgName": "music_album_art (4)",
				"ranking": 4
				},
				{ "index": 4,
				"title": "늦은 밤 너의 집 앞 골목길에서",
				"artist": "노을",
				"album": "늦은 밤 너의 집 앞 골목길에서",
				"imgName": "music_album_art (5)",
				"ranking": 5
				},
				{ "index": 5,
				"title": "아로하",
				"artist": "조정석",
				"album": "슬기로운 의사생활 OST Part 3 (tvN 목요드라마)",
				"imgName": "music_album_art (6)",
				"ranking": 6
				},
				{ "index": 6,
				"title": "에잇 (Prod. & Feat. SUGA of BTS)",
				"artist": "아이유 (IU)",
				"album": "에잇",
				"imgName": "music_album_art (7)",
				"ranking": 7
				},
				{ "index": 7,
				"title": "Psycho",
				"artist": "Red Velvet (레드벨벳)",
				"album": "'The ReVe Festival' Finale",
				"imgName": "music_album_art (8)",
				"ranking": 8
				},
				{ "index": 8,
				"title": "HIP",
				"artist": "마마무(Mamamoo)",
				"album": "reality in BLACK",
				"imgName": "music_album_art (9)",
				"ranking": 9
				},
				{ "index": 9,
				"title": "어떻게 이별까지 사랑하겠어, 널 사랑하는 거지",
				"artist": "AKMU (악동뮤지션)",
				"album": "항해",
				"imgName": "music_album_art (10)",
				"ranking": 10
				},
				{ "index": 10,
				"title": "시작",
				"artist": "가호 (Gaho)",
				"album": "이태원 클라쓰 OST Part.2 (JTBC 금토드라마)",
				"imgName": "music_album_art (11)",
				"ranking": 11
				},
				{ "index": 11,
				"title": "오늘도 빛나는 너에게 (To You My Light) (Feat.이라온)",
				"artist": "마크툽 (Maktub)",
				"album": "Red Moon : To You My Light",
				"imgName": "music_album_art (12)",
				"ranking": 12
				},
				{ "index": 12,
				"title": "Love poem",
				"artist": "아이유 (IU)",
				"album": "Love poem",
				"imgName": "music_album_art (13)",
				"ranking": 13
				},
				{ "index": 13,
				"title": "어떻게 지내 (Prod. by VAN.C)",
				"artist": "오반 (OVAN)",
				"album": "어떻게 지내",
				"imgName": "music_album_art (14)",
				"ranking": 14
				},
				{ "index": 14,
				"title": "Square (2017)",
				"artist": "백예린 (Yerin Baek) ",
				"album": "Every letter I sent you.",
				"imgName": "music_album_art (15)",
				"ranking": 15
				},
				{ "index": 15,
				"title": "Dynamite",
				"artist": "방탄소년단 ",
				"album": "Dynamite (DayTime Ver.)",
				"imgName": "music_album_art (16)",
				"ranking": 16
				},
				{ "index": 16,
				"title": "작은 것들을 위한 시 (Boy With Luv) (Feat. Halsey)",
				"artist": "방탄소년단 ",
				"album": "MAP OF THE SOUL : PERSONA",
				"imgName": "music_album_art (17)",
				"ranking": 17
				},
				{ "index": 17,
				"title": "살짝 설렜어 (Nonstop)",
				"artist": "오마이걸 (OH MY GIRL)",
				"album": "NONSTOP",
				"imgName": "music_album_art (18)",
				"ranking": 18
				},
				{ "index": 18,
				"title": "안녕",
				"artist": "폴킴",
				"album": "호텔 델루나 OST Part.10 (tvN 토일드라마)",
				"imgName": "music_album_art (19)",
				"ranking": 19
				},
				{ "index": 19,
				"title": "모든 날, 모든 순간 (Every day, Every Moment)",
				"artist": "폴킴",
				"album": "'키스 먼저 할까요?' OST Part. 3 (SBS 월화드라마)",
				"imgName": "music_album_art (20)",
				"ranking": 20
				},
				{ "index": 20,
				"title": "마음을 드려요",
				"artist": "아이유 (IU)",
				"album": "사랑의 불시착 OST Part 11 (tvN 토일 드라마)",
				"imgName": "music_album_art (21)",
				"ranking": 21
				},
				{ "index": 21,
				"title": "Dolphin",
				"artist": "오마이걸 (OH MY GIRL)",
				"album": "NONSTOP",
				"imgName": "music_album_art (22)",
				"ranking": 22
				},
				{ "index": 22,
				"title": "마리아 (Maria)",
				"artist": "화사 (Hwa Sa)",
				"album": "Maria",
				"imgName": "music_album_art (23)",
				"ranking": 23
				},
				{ "index": 23,
				"title": "Downtown Baby",
				"artist": "블루 (BLOO)",
				"album": "Downtown Baby",
				"imgName": "music_album_art (24)",
				"ranking": 24
				},
				{ "index": 24,
				"title": "How You Like That",
				"artist": "BLACKPINK",
				"album": "How You Like That",
				"imgName": "music_album_art (25)",
				"ranking": 25
				},
				{ "index": 25,
				"title": "아마두 (Feat. 우원재 & 김효은 & 넉살 & Huckleberry P)",
				"artist": "염따 & 딥플로우 & 팔로알토 (Paloalto) & The Quiett & 사이먼 도미닉",
				"album": "Dingo X DAMOIM (Part 2)",
				"imgName": "music_album_art (26)",
				"ranking": 26
				},
				{ "index": 26,
				"title": "다시 여기 바닷가",
				"artist": "싹쓰리 (유두래곤 & 린다G & 비룡)",
				"album": "다시 여기 바닷가",
				"imgName": "music_album_art (27)",
				"ranking": 27
				},
				{ "index": 27,
				"title": "처음처럼",
				"artist": "엠씨더맥스 (M.C the MAX)",
				"album": "CEREMONIA",
				"imgName": "music_album_art (28)",
				"ranking": 28
				},
				{ "index": 28,
				"title": "조금 취했어 (Prod. by 2soo)",
				"artist": "임재현",
				"album": "조금 취했어",
				"imgName": "music_album_art (29)",
				"ranking": 29
				},
				{ "index": 29,
				"title": "사랑이란 멜로는 없어",
				"artist": "전상근",
				"album": "사랑이란 멜로는 없어",
				"imgName": "music_album_art (30)",
				"ranking": 30
				},
				{ "index": 30,
				"title": "좋은 사람 있으면 소개시켜줘",
				"artist": "조이 (JOY)",
				"album": "슬기로운 의사생활 OST Part 2 (tvN 목요드라마)",
				"imgName": "music_album_art (31)",
				"ranking": 31
				},
				{ "index": 31,
				"title": "시든 꽃에 물을 주듯",
				"artist": "HYNN (박혜원)",
				"album": "시든 꽃에 물을 주듯",
				"imgName": "music_album_art (32)",
				"ranking": 32
				},
				{ "index": 32,
				"title": "ON",
				"artist": "방탄소년단",
				"album": "MAP OF THE SOUL : 7",
				"imgName": "music_album_art (33)",
				"ranking": 33
				},
				{ "index": 33,
				"title": "사랑하게 될 줄 알았어",
				"artist": "전미도",
				"album": "슬기로운 의사생활 OST Part 11 (tvN 목요드라마)",
				"imgName": "music_album_art (34)",
				"ranking": 34
				},
				{ "index": 34,
				"title": "나의 오랜 연인에게",
				"artist": "다비치",
				"album": "나의 오랜 연인에게",
				"imgName": "music_album_art (35)",
				"ranking": 35
				},
				{ "index": 35,
				"title": "취기를 빌려 (취향저격 그녀 X 산들)",
				"artist": "산들",
				"album": "취기를 빌려 (취향저격 그녀 X 산들)",
				"imgName": "music_album_art (36)",
				"ranking": 36
				},
				{ "index": 36,
				"title": "돌덩이",
				"artist": "하현우 (국카스텐)",
				"album": "이태원 클라쓰 OST Part.3 (JTBC 금토드라마)",
				"imgName": "music_album_art (37)",
				"ranking": 37
				},
				{ "index": 37,
				"title": "WANNABE",
				"artist": "ITZY (있지)",
				"album": "IT'z ME",
				"imgName": "music_album_art (38)",
				"ranking": 38
				},
				{ "index": 38,
				"title": "다시 난, 여기",
				"artist": "백예린 (Yerin Baek)",
				"album": "사랑의 불시착 OST Part 4 (tvN 토일 드라마)",
				"imgName": "music_album_art (39)",
				"ranking": 39
				},
				{ "index": 39,
				"title": "사랑에 연습이 있었다면 (Prod. by 2soo)",
				"artist": "임재현",
				"album": "사랑에 연습이 있었다면",
				"imgName": "music_album_art (40)",
				"ranking": 40
				},
				{ "index": 40,
				"title": "오래된 노래",
				"artist": "Standing Egg (스탠딩 에그)",
				"album": "오래된 노래",
				"imgName": "music_album_art (41)",
				"ranking": 41
				},
				{ "index": 41,
				"title": "포장마차",
				"artist": "황인욱",
				"album": "포장마차",
				"imgName": "music_album_art (42)",
				"ranking": 42
				},
				{ "index": 42,
				"title": "너를 만나",
				"artist": "폴킴",
				"album": "너를 만나",
				"imgName": "music_album_art (43)",
				"ranking": 43
				},
				{ "index": 43,
				"title": "사랑이 식었다고 말해도 돼",
				"artist": "먼데이 키즈 (Monday Kiz)",
				"album": "사랑이 식었다고 말해도 돼",
				"imgName": "music_album_art (44)",
				"ranking": 44
				},
				{ "index": 44,
				"title": "다시 만날까 봐",
				"artist": "V.O.S",
				"album": "다시 만날까 봐",
				"imgName": "music_album_art (45)",
				"ranking": 45
				},
				{ "index": 45,
				"title": "기억해줘요 내 모든 날과 그때를",
				"artist": "거미 (Gummy)",
				"album": "호텔 델루나 OST Part.7 (tvN 토일드라마)",
				"imgName": "music_album_art (46)",
				"ranking": 46
				},
				{ "index": 46,
				"title": "우리 왜 헤어져야 해",
				"artist": "신예영",
				"album": "우리 왜 헤어져야 해",
				"imgName": "music_album_art (47)",
				"ranking": 47
				},
				{ "index": 47,
				"title": "나비와 고양이 (Feat. 백현 (BAEKHYUN))",
				"artist": "볼빨간사춘기",
				"album": "사춘기집Ⅱ 꽃 본 나비",
				"imgName": "music_album_art (48)",
				"ranking": 48
				},
				{ "index": 48,
				"title": "니 소식",
				"artist": "송하예",
				"album": "니 소식",
				"imgName": "music_album_art (49)",
				"ranking": 49
				},
				{ "index": 49,
				"title": "다시는 사랑하지 않고, 이별에 아파하기 싫어",
				"artist": "백지영",
				"album": "다시는 사랑하지 않고, 이별에 아파하기 싫어",
				"imgName": "music_album_art (50)",
				"ranking": 50
				},
			]
		},
		{
			"playList": {
				"id": 101,
				"name": "Top 10",
				"isEditable": true,
			},
			"musicList": [
				{ "index": 0,
					"title": "METEOR",
					"artist": "창모 (CHANGMO)",
					"album": "Boyhood",
					"imgName": "music_album_art (1)",
					"ranking": 1
				},
				{ "index": 1,
					"title": "Blueming",
					"artist": "아이유 (IU)",
					"album": "Love poem",
					"imgName": "music_album_art (2)",
					"ranking": 2
				},
				{ "index": 2,
					"title": "아무노래",
					"artist": "지코 (ZICO)",
					"album": "아무노래",
					"imgName": "music_album_art (3)",
					"ranking": 3
				},
				{ "index": 3,
					"title": "흔들리는 꽃들 속에서 네 샴푸향이 느껴진거야",
					"artist": "장범준",
					"album": "멜로가 체질 OST Part 3 (JTBC 금토 드라마)",
					"imgName": "music_album_art (4)",
					"ranking": 4
				},
				{ "index": 4,
					"title": "늦은 밤 너의 집 앞 골목길에서",
					"artist": "노을",
					"album": "늦은 밤 너의 집 앞 골목길에서",
					"imgName": "music_album_art (5)",
					"ranking": 5
				},
				{ "index": 5,
					"title": "아로하",
					"artist": "조정석",
					"album": "슬기로운 의사생활 OST Part 3 (tvN 목요드라마)",
					"imgName": "music_album_art (6)",
					"ranking": 6
				},
				{ "index": 6,
					"title": "에잇 (Prod. & Feat. SUGA of BTS)",
					"artist": "아이유 (IU)",
					"album": "에잇",
					"imgName": "music_album_art (7)",
					"ranking": 7
				},
				{ "index": 7,
					"title": "Psycho",
					"artist": "Red Velvet (레드벨벳)",
					"album": "'The ReVe Festival' Finale",
					"imgName": "music_album_art (8)",
					"ranking": 8
				},
				{ "index": 8,
					"title": "HIP",
					"artist": "마마무(Mamamoo)",
					"album": "reality in BLACK",
					"imgName": "music_album_art (9)",
					"ranking": 9
				},
				{ "index": 9,
					"title": "어떻게 이별까지 사랑하겠어, 널 사랑하는 거지",
					"artist": "AKMU (악동뮤지션)",
					"album": "항해",
					"imgName": "music_album_art (10)",
					"ranking": 10
				},
			]
		},
		{
			"playList": {
				"id": 102,
				"name": "내 재생 목록 A",
				"isEditable": true,
			},
			"musicList": [
				{ "index": 0,
					"title": "Blueming",
					"artist": "아이유 (IU)",
					"album": "Love poem",
					"imgName": "music_album_art (2)",
					"ranking": 2
				},
				{ "index": 1,
					"title": "아무노래",
					"artist": "지코 (ZICO)",
					"album": "아무노래",
					"imgName": "music_album_art (3)",
					"ranking": 3
				},
				{ "index": 2,
					"title": "흔들리는 꽃들 속에서 네 샴푸향이 느껴진거야",
					"artist": "장범준",
					"album": "멜로가 체질 OST Part 3 (JTBC 금토 드라마)",
					"imgName": "music_album_art (4)",
					"ranking": 4
				},
				{ "index": 3,
					"title": "아로하",
					"artist": "조정석",
					"album": "슬기로운 의사생활 OST Part 3 (tvN 목요드라마)",
					"imgName": "music_album_art (6)",
					"ranking": 6
				},
				{ "index": 4,
					"title": "에잇 (Prod. & Feat. SUGA of BTS)",
					"artist": "아이유 (IU)",
					"album": "에잇",
					"imgName": "music_album_art (7)",
					"ranking": 7
				},
				{ "index": 5,
					"title": "Psycho",
					"artist": "Red Velvet (레드벨벳)",
					"album": "'The ReVe Festival' Finale",
					"imgName": "music_album_art (8)",
					"ranking": 8
				},
				{ "index": 6,
					"title": "HIP",
					"artist": "마마무(Mamamoo)",
					"album": "reality in BLACK",
					"imgName": "music_album_art (9)",
					"ranking": 9
				},
				{ "index": 7,
					"title": "시작",
					"artist": "가호 (Gaho)",
					"album": "이태원 클라쓰 OST Part.2 (JTBC 금토드라마)",
					"imgName": "music_album_art (11)",
					"ranking": 11
				},
				{ "index": 8,
					"title": "오늘도 빛나는 너에게 (To You My Light) (Feat.이라온)",
					"artist": "마크툽 (Maktub)",
					"album": "Red Moon : To You My Light",
					"imgName": "music_album_art (12)",
					"ranking": 12
				},
				{ "index": 9,
					"title": "Love poem",
					"artist": "아이유 (IU)",
					"album": "Love poem",
					"imgName": "music_album_art (13)",
					"ranking": 13
				},
				{ "index": 10,
					"title": "Square (2017)",
					"artist": "백예린 (Yerin Baek) ",
					"album": "Every letter I sent you.",
					"imgName": "music_album_art (15)",
					"ranking": 15
				},
				{ "index": 11,
					"title": "Dynamite",
					"artist": "방탄소년단 ",
					"album": "Dynamite (DayTime Ver.)",
					"imgName": "music_album_art (16)",
					"ranking": 16
				},
				{ "index": 12,
					"title": "작은 것들을 위한 시 (Boy With Luv) (Feat. Halsey)",
					"artist": "방탄소년단 ",
					"album": "MAP OF THE SOUL : PERSONA",
					"imgName": "music_album_art (17)",
					"ranking": 17
				},
				{ "index": 13,
					"title": "안녕",
					"artist": "폴킴",
					"album": "호텔 델루나 OST Part.10 (tvN 토일드라마)",
					"imgName": "music_album_art (19)",
					"ranking": 19
				},
				{ "index": 14,
					"title": "마음을 드려요",
					"artist": "아이유 (IU)",
					"album": "사랑의 불시착 OST Part 11 (tvN 토일 드라마)",
					"imgName": "music_album_art (21)",
					"ranking": 21
				},
				{ "index": 15,
					"title": "Dolphin",
					"artist": "오마이걸 (OH MY GIRL)",
					"album": "NONSTOP",
					"imgName": "music_album_art (22)",
					"ranking": 22
				},
				{ "index": 16,
					"title": "마리아 (Maria)",
					"artist": "화사 (Hwa Sa)",
					"album": "Maria",
					"imgName": "music_album_art (23)",
					"ranking": 23
				},
				{ "index": 17,
					"title": "How You Like That",
					"artist": "BLACKPINK",
					"album": "How You Like That",
					"imgName": "music_album_art (25)",
					"ranking": 25
				},
				{ "index": 18,
					"title": "아마두 (Feat. 우원재 & 김효은 & 넉살 & Huckleberry P)",
					"artist": "염따 & 딥플로우 & 팔로알토 (Paloalto) & The Quiett & 사이먼 도미닉",
					"album": "Dingo X DAMOIM (Part 2)",
					"imgName": "music_album_art (26)",
					"ranking": 26
				},
			]
		},
		{
			"playList": {
				"id": 103,
				"name": "SSAFY 실습용",
				"isEditable": true,
			},
			"musicList": [],
		}
	]
}