import axios from "axios";
import MainDummy from "./dummy/MainDummy"

export default {
  isDummyMode() {
    return true;
  },
  getPlayList() {
    if (this.isDummyMode()) {
      return MainDummy.getPlayList().data.playList;
    } else {
      axios.get('/playList')
      .then(function (response) {
        // handle success
        return response;
      });
      // .catch(function (error) {
      //   // handle error
      //   console.log(error);
      // })
      // .then(function () {
      //   // always executed
      // });
    }
  },
  getMusicList(playListId = 0) {
    if (this.isDummyMode()) {
      return MainDummy.getMusicList(playListId).data.musicList;
    } else {
      axios.get('/musicList?ID=12345')
      .then(function (response) {
        // handle success
        return response;
      });
      // .catch(function (error) {
      //   // handle error
      //   console.log(error);
      // })
      // .then(function () {
      //   // always executed
      // });
    }
  },
  // 해당 음악이 포함되어 있는 재생 목록 반환
  contains(musicItem) {
    if (this.isDummyMode()) {
      let containsPlayList = [];
      let myMusic = MainDummy.myMusicList;

      myMusic.forEach(element => {
        element.musicList.some(music => {
          if(music.title == musicItem.title) {
            containsPlayList.push(element.playList);
          }
          return (music.title == musicItem.title);
      });
      });
      return containsPlayList;
    } else {
      return [];
    }
  },
  // 재생목록에 음악 추가
  addToPlayList(playListId, musicItem) {
    if (this.isDummyMode()) {
      let myMusic = MainDummy.myMusicList;
      let plistIndex = 0;
      let musicIndex = 0;
      let isContains = false;

      myMusic.forEach(function(element, index){
        if (element.playList.id === playListId) {
          plistIndex = index;
        }
      });

      // 포함 여부 확인
      myMusic[plistIndex].musicList.some(function(music, index) {
        if(music.title == musicItem.title) {
          isContains = true;
          musicIndex = index;
        }
        return (music.title == musicItem.title);
     });

     if (!isContains) {
        musicItem.index = myMusic[plistIndex].musicList.length;
        myMusic[plistIndex].musicList.push(musicItem);
        // 추가 성공
        return true;
     } else {
        myMusic[plistIndex].musicList.splice(musicIndex, 1);
       // 추가 실패 : 중복된 노래
       return false;
     }
    }
  }
}