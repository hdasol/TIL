<template>
  <!-- 음악 리스트  (ref -> 스크립트로 스크롤하기 위해 요소 접근) -->
  <div class="music-list" :class="{ 'controller-padding': isSelected }" ref="musicList">
    <MusicItem v-for="(item, index) in musicList" :key="index" :item="item" />
  </div>
</template>

<script>
import "./musicList.scss";
import MusicItem from "./item/MusicItem.vue"

export default {
  name: 'MusicList',
  components: {
    MusicItem,
  },
  // : props
  
  // : data
  data() {
    return {
    }
  },
  // : computed
  computed: {
    musicList() {
      return this.$store.state.main.musicList;
    },
    isSelected() {
      return this.$store.getters['main/isSelected'];
    },
  },
  // : lifecycle hook
  mounted() {
    this.setListElement();
  },
  // : methods
  methods: {
    // 스크립트로 스크롤 하기 위해 요소 등록  ( MusicController에서 수행 )
    setListElement() {
      this.$nextTick(() => {
        this.$store.commit('main/setMusicListElement', this.$refs.musicList);
      });
    },
  }
}
</script>
