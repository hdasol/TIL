<template>
  <div class="music-item" :style="{ 'background' : musicColor }">
    <div class="music-item-bg" @click="onItemClick" />
    <!-- Album Art -->
    <img class="album" :src="imagePath"/>
    <div class="music-info">
      <!-- Music Title  -->
      <h6>{{item.title}}</h6>
      <!-- Artist -->
      <p>{{item.artist}}</p>
    </div>
    <!-- Add Button -->
    <div class="btn-add" @click="onAddBtnClick">
      <span />
      <span />
    </div>
  </div>
</template>

<script>
import "./musicItem.scss";
import utils from "@/common/utils.js"

export default {
  name: 'MusicItem',
  components: {
  },
  // : props
  props: {
    item : {},
  },
  // : data
  
  // : computed
  computed: {
    imagePath() {
      return utils.getImagePath(this.item.imgName, true);
    },
    isSelectedMusic() {
      return this.$store.state.main.currentMusic.title === this.item.title;
    },
    // 현재 재생 중인 음악 배경 색상 변경
    musicColor() {
      if (this.isSelectedMusic) {
        return this.$store.state.main.musicColor.hex + '30';  // 투명도 값
      } else {
        return '';
      }
    },
  },
  // : lifecycle hook
  
  // : methods
  methods: {
    // 현재 음악 선택 -> 재생
    onItemClick() {
      this.$store.commit('main/setCurrentMusic', this.item);
    },
    onAddBtnClick() {
      this.$store.commit('playListEditor/selectMusic', this.item);
    }
  }
}
</script>
