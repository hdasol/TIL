<template>
  <div class="music-controller">
    <!-- 음악 진행 바 -->
    <div class="music-progress-bar-wrap" ref="musicProgress">
      <span :style="{ right: (100 - musicPosition) + '%', backgroundColor: musicColor }"></span>
      <div class="music-progress-circle"  :style="{ left: musicPosition + '%', backgroundColor: musicColor }"></div>
      <div class="music-progress-bar"></div>
    </div>

    <!-- 음악 컨트롤러 -->
    <div class="music-controller-item">

      <!-- 이전 음악 버튼 -->
      <div class='btn-next isPrev' @click="onNextClick(true)">
        <span></span>
      </div>

      <!-- 음악 재생 버튼 -->
      <div class='btn-play' :class="{ paused : isPlaying }" @click="onPlayClick"></div>
      
      <!-- 다음 음악 버튼 -->
      <div class='btn-next' @click="onNextClick(false)">
        <span></span>
      </div>
      
      <!-- 현재 재생 중인 음악 정보 -->
      <div class="music-controller-info" @click="scrollToItem">
        <h6>{{currentMusic.title}}</h6>
        <p>{{currentMusic.artist}}</p>
      </div>
    </div>
    <div :class="{ 'music-progress-draggable': isDrag }" ref="musicProgressDraggable"></div>
  </div>
</template>

<script>
import "./musicController.scss";

export default {
  name: 'MusicController',
  components: {
  },
  // : props
  
  // : data
  data() {
    return {
      isPlaying: false,
      musicPosition: 0,
      positionInterval: {},
      musicData: { title: "" },
      isDrag: false,
    }
  },
  // : computed
  computed: {
    currentMusic() {
      let _currentMusic = this.$store.state.main.currentMusic;
      this.onChangeMusic(_currentMusic);
      return _currentMusic;
    },
    musicColor() {
      return this.$store.state.main.musicColor.hex;
    },
  },
  // : lifecycle hook
  mounted(){
    // Progress Bar 이벤트 등록
    this.$refs.musicProgress.addEventListener("mousedown", this.progressDown, false);
    this.$refs.musicProgressDraggable.addEventListener("mouseup", this.progressUp, false);
    this.$refs.musicProgressDraggable.addEventListener("mouseleave", this.progressUp, false);
  },
  beforeUnmount() {
    clearInterval(this.positionInterval);
    this.$refs.musicProgress.removeEventListener("mousedown", this.progressDown, false);
    this.$refs.musicProgressDraggable.removeEventListener("mouseup", this.progressUp, false);
    this.$refs.musicProgressDraggable.removeEventListener("mouseleave", this.progressUp, false);
  },
  // : methods
  methods: {
    // 재생 버튼 클릭
    onPlayClick() {
      if (!this.isPlaying) {
        this.playMusic();
      } else {
        this.stopMusic();
      }
    },
    // 이전 / 다음 버튼 클릭
    onNextClick(isPrev) {
      this.$store.commit('main/nextMusic', !isPrev);
      this.scrollToItem();
    },
    // 해당 위치로 스크롤
    scrollToItem() {
      this.$nextTick(() => {
        this.$store.commit('main/scrollToMusicItem', (this.currentMusic.index - 2) * 72);
      });
    },
    onChangeMusic(newMusic) {
      if (this.musicData.title !== newMusic.title) {
        this.musicData = newMusic;
        this.musicPosition = 0;
        this.playMusic();
      }
    },
    playMusic() {
      if (this.isPlaying) {
        clearInterval(this.positionInterval);
      }
      this.isPlaying = true;

      // Music progress bar Interval -> 1초마다 1% 이동
      this.positionInterval = setInterval(() => {
        this.musicPosition++;
        // 끝까지 도달 시 중지
        if (this.musicPosition > 97) {
          this.onNextClick(false);
          this.musicPosition = 0;
          clearInterval(this.positionInterval);
        }
      }, 1000);
    },
    stopMusic() {
      this.isPlaying = false;
      clearInterval(this.positionInterval);
    },
    // Progress Events
    progressMove(e) {
      let currentPosition = (e.offsetX / this.$refs.musicProgress.offsetWidth) * 100
      currentPosition > 97 ? currentPosition = 97 : currentPosition;  // 끝 도달 시
      this.musicPosition = currentPosition;
    },
    progressDown(e) {
      this.isDrag = true;
      this.stopMusic();
      this.progressMove(e);
      this.$refs.musicProgressDraggable.addEventListener("mousemove", this.progressMove, false)
    },
    progressUp() {
      this.$refs.musicProgressDraggable.removeEventListener("mousemove", this.progressMove, false)
      this.isDrag = false;
      this.playMusic();
    },
  }
}
</script>
