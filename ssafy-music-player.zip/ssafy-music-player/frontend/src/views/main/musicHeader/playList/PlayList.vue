<template>
  <ul class="play-list-wrap">
    <li v-for="(item) in playList" :key="item.id" @click="selectPlayList(item)">
      <p v-if="isSelected(item)" :style="{ 
        color : textColor, 
        backgroundColor: musicColor.hex,
        }">{{ item.name }}</p>
      <p v-else>{{ item.name }}</p>
    </li>
  </ul>
</template>

<script>
import "./playList.scss";
import utils from "@/common/utils.js"
import MainApi from "@/api/MainApi.js"

export default {
  name: 'PlayList',
  components: {
  },
  // : props
  
  // : data
  data() {
    return {
      textColor: '',
    }
  },
  // : computed
  computed: {
    playList() {
      return this.$store.state.main.playList;
    },
    selectedPlayList() {
      return this.$store.state.main.selectedPlayList;
    },
    musicColor() {
      this.setTextColor();
      return this.$store.state.main.musicColor;
    },
  },
  // : lifecycle hook
  async mounted() {
    this.initList();
  },
  // : methods
  methods: {
    async initList() {
      await this.requestPlayList();
      this.selectPlayList(this.playList[0]);
    },
    async requestPlayList() {
      const response = await MainApi.getPlayList();
      this.$store.commit('main/setPlayList', response);
    },
    async requestMusicList(playListId) {
      const response = await MainApi.getMusicList(playListId);
      this.$store.commit('main/setMusicList', response.musicList);
    },
    selectPlayList(playList) {
      this.$store.commit('main/setSelectedPlayList', playList);
      this.requestMusicList(playList.id)
      this.scrollToItem();
      this.setEmptyItem();
    },
    setEmptyItem() {
      let emptyItem = { 
          index: -1,
          title: "",
          artist: "",
          album: "",
          imgName: "music_album_art (0)",
          ranking: 0
				}
      this.$store.commit('main/setCurrentMusic', emptyItem);
    },
    isSelected(list) {
      return Number(list.id) === Number(this.selectedPlayList.id);
    },
    // 음악 앨범 아트 색상에 따라 text 색상 (black / white) 결정
    setTextColor() {
      const rgb = this.$store.state.main.musicColor.rgb;
      this.textColor = utils.getColorByBrightness(rgb);
    },
    // 해당 위치로 스크롤
    scrollToItem() {
      this.$nextTick(() => {
        this.$store.commit('main/scrollToMusicItem', 0);
      });
    },
  }
}
</script>
