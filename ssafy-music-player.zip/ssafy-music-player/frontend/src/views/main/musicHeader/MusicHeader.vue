<template>
  <div class="music-header-wrap">
    <div class="music-header">
      <h6>SSAFY Music</h6>
    </div>

    <!-- 음악 상태창 -->
    <div class="music-status-wrap" :style="musicStatusStlye">
      <music-wave v-if="isSelected"/>
    </div>

    <!-- 선택 텝 -->
    <PlayList />
  </div>
</template>

<script>
import "./musicHeader.scss";
import PlayList from "./playList/PlayList";
import utils from '@/common/utils.js';
import MusicWave from '../../common/MusicWave.vue';

export default {
  name: 'MusicHeader',
  components: {
    PlayList,
    MusicWave,
  },
  // : props

  // : data
  data() {
    return {
      img: {},
    }
  },
  // : computed
  computed: {
    isSelected() {
      return this.$store.getters['main/isSelected'];
    },
    musicStatusStlye() {
      this.changeMusicColor();
      return { 
        backgroundImage: 'url("' + this.imagePath + '")',
        backgroundPosition: "center center",
        backgroundRepeat: "no-repeat",
      }
    },
    imagePath() {
      if (this.$store.state.main.currentMusic.imgName === '') return '';
      return utils.getImagePath(this.$store.state.main.currentMusic.imgName, true);
    },
  },
  // : lifecycle hook
  created() {
    this.initColorThief();
  },
  // : methods
  methods: {
    // 앨범 아트에서 가장 많이 사용한 색상값 추출 (Color Thief Lib)
    initColorThief() {
      this.img = new Image();
      this.img.crossOrigin = 'Anonymous';
      // 이미지 src 변경 시 호출
      this.img.addEventListener('load', () => {
        this.updateMusciColor();
      })
    },
    updateMusciColor() {
      let color = utils.getImageColor(this.img);
      this.$store.commit('main/setMusicColor', color);
    },
    // 앨범 아트 변경 -> 색상 추출
    changeMusicColor() {
      this.img.src =  this.imagePath;
    },
  }
}
</script>
