<template>
  <div class="main-wrap">
    <Animation />
    <div class="main-container">
      <!-- 배경화면 -->
      <div class="main-bg">
        <!-- 블러 처리된 배경 이미지 -->
        <div :style="blurBgStyle"></div>
        <!-- 그라데이션 효과 -->
        <div class="main-bg-gradation"></div>
      </div>

      <!--  음악 헤더  -->
      <MusicHeader />

      <!--  음악 리스트  -->
      <MusicList />

      <!--  음악 컨트롤러  -->
      <MusicController v-if="isSelected"/>

      <!-- 플레이 리스트 편집 창 -->
      <PlayListEditor v-if="isPlayListEdiorVisible"/>

      <!-- 토스트 팝업 -->
      <transition name="toast-fade">
        <s-toast v-if="isToastVisible" />
      </transition>
    </div>
  </div>
</template>

<script>
import "./main.scss";
import MusicHeader from "./musicHeader/MusicHeader";
import MusicList from "./musicList/MusicList";
import MusicController from './musicController/MusicController.vue';
import PlayListEditor from './playListEditor/PlayListEditor.vue';
import SToast from '../common/SToast.vue';
import utils from "@/common/utils.js"
import Animation from '../examples/animation/Animation.vue';

export default {
  name: 'Main',
  components: {
    MusicHeader,
    MusicList,
    MusicController,
    PlayListEditor,
    SToast,
    Animation,
  },
  // : props

  // : data
  data() {
    return {
    }
  },
  // : computed
  computed: {
    isSelected() {
      return this.$store.getters['main/isSelected'];
    },
    isPlayListEdiorVisible() {
      return this.$store.getters['playListEditor/isVisible'];
    },
    isToastVisible() {
      return this.$store.getters['toast/isVisible'];

    },
    imagePath() {
      if (this.$store.state.main.currentMusic.imgName === '') return '';
      return utils.getImagePath(this.$store.state.main.currentMusic.imgName, true);
    },
    // 현재 선택한 음악 앨범을 배경으로 지정 (비동기) -> 블러 효과 적용 -> 가장자리 자르기
    blurBgStyle() {
      return {
        backgroundImage: 'url("' + this.imagePath + '")',
        backgroundPosition: "center center",
        backgroundSize: "cover",
        backgroundRepeat: "no-repeat",
        '-webkit-filter': "blur(4px) contrast(125%) brightness(75%)",
        filter: "blur(4px) contrast(125%) brightness(75%)",
        content:"",
        height: "100%",
        width: "100%",
        position: "absolute",
        'z-index': "-1",
        top: "0",
        left: "0",
        right: "0",
        transform: "scale(1.1)",
      }
    }
  },
  // : lifecycle hook
  
  // : methods
  methods: {
  }
}
</script>
