<template>
  <div>
    <!-- 바깥 영역 > 클릭 시 닫기 -->
    <div class="play-list-editor-outside" @click="onClose"/>
    <div class="play-list-editor-wrap">
      <!-- 여기부터 코드 작성 -->
      <h4>추가하기 : {{ currentItem.title }}</h4>
      
      <!-- 닫기 버튼 -->
      <span class="play-list-editor-close" @click="onClose">X</span>

      <!-- 재생 목록 불러오기 -->
      <ul class="play-list-editor-items">
        <li v-for="(item) in editablePlayList" :key="item.id" @click="selectPlayList(item)">
          <!-- Radio Component -->
          <s-radio :text="item.name" :checked="isContains(item.id)"/>
        </li>
      </ul>

      <!-- 새 재생 목록 만들기 (추가 구현) -->
      <h4 @click="createNew">새 재생 목록 만들기</h4>
      <div v-if="isNew" class="play-list-editor-new">
        <h4>추가 구현</h4>
      </div>
    </div>
  </div>
</template>

<script>
import "./playListEditor.scss";
import MainApi from "@/api/MainApi.js"
import SRadio from '../../common/SRadio.vue';

/* 
    * Api 명세서 (더미 데이터 기반) *

    ◇ Model 정의 
    ─────────────────────────────────────────────────────────────────────────────────────────────────────

    - PlayList Model (재생 목록)
    {
      "id": 101,
      "name": "재생 목록 이름",
      "isEditable": true,  // 재생 목록 편집 가능 여부
    }

    - MusicItem Model (음악 정보)
    {
      "index": 0,
      "title": "음악 제목",
      "artist": "가수",
      "album": "앨범명",
      "imgName": "앨범 아트 파일명",
      "ranking": 1   // 차트 순위
    }

    ◇ Data 구조 정의
    ─────────────────────────────────────────────────────────────────────────────────────────────────────
    - playListArray  : [{ playList }, { playList }, { playList } ... ]
    - musicList      : [{ musicItem }, { musicItem }, { musicItem } ... ]
    - myMusicList    : [{ playList, musicList }, { playList, musicList }, { playList, musicList } ... ]

    ◇ Api 결과 값 예시
    ─────────────────────────────────────────────────────────────────────────────────────────────────────
    {
      "isSuccess": true,    // 성공 여부
      "data": {             // 결과 데이터
				"playList": [
          {
            "id": 0,
            "name": '인기뮤직',
            "isEditable": false,
          },
          {
            "id": 101,
            "name": "Top 10",
            "isEditable": true,
          },
          {
            "id": 102,
            "name": "내 재생 목록 A",
            "isEditable": true,
			    },
        ]
			}
		}
*/

export default {
  name: 'PlayListEditor',
  components: {
    SRadio
  },
  // : props
  props: {
  },
  // : data
  data() {
    return {
      playListArray: [],
      isNew: false,
    }
  },
  // : computed
  computed: {
    // 현재 선택된 음악
    currentItem() {
      return this.$store.state.playListEditor.selectedMusic;
    },
    // 편집 가능한 재생목록만 보여주기
    editablePlayList() {
      return this.$store.state.main.playList.filter(item => item.isEditable);
    },
  },
  // : lifecycle hook
  mounted() {
    this.updatePlayListArray();
  },
  // : methods
  methods: {
    // 재생목록 선택
    selectPlayList(playList) {
      // 여기만 작성하면 재생 목록 편집이 동작할 것 같습니다... (아마도)
      console.log(playList);
    },

    /*
        * 사소한 팁 - 재생 목록 편집 기능 고려 사항
        (도움없이 직접 구현하고 싶으신 분은 안 보고 해보세요.)

        ┌───────────────────────────────────────────────────────┐
        │                                                       │
        │      1. 추가/제거를 하나의 로직으로 할 순 없을까?       │
        │      2. 추가/제거 완료 후 바로 화면에 반영되는가?       │
        │      3. 기능 완료 후 편집 화면 창은 닫아야하는가?       │
        │                                                       │
        └───────────────────────────────────────────────────────┘
    */

    onClose() {
      this.$store.commit('playListEditor/selectMusic', '');
    },
    // 새 재생 목록 만들기 기능 (추가 구현)
    createNew() {
      this.isNew = !this.isNew;
    },
    // 추가할 음악이 해당 재생목록에 포함되어 있는지 여부
    isContains(playListId) {
      let result = false;
      this.playListArray.some(element => {
        if (element.id === playListId) { result = true }
        return (element.id === playListId);
      });
      return result;
    },
    // ──────────────────────────────────────────────────────────────────────
    //            API   (로컬 더미데이터)
    // ──────────────────────────────────────────────────────────────────────
    /*
      선택한 음악이 포함되어 있는 재생목록 배열 반환 API

      > MainApi.contains(musicItem);
      > return -> playListArray
    */
    async updatePlayListArray() {
      let response = await MainApi.contains(this.currentItem);
      // 로컬 data에 저장
      this.playListArray = response;
    },
    /*
      선택한 음악을 재생목록에 추가/삭제 API

      > MainApi.addToPlayList(playListId, musicItem);
      > return -> 추가 완료: true / 삭제 완료: false
    */
    async addToPlayList(playListId, musicItem) {
      let response = await MainApi.addToPlayList(playListId, musicItem);

      // Toast 알림
      this.$store.commit('toast/showToast', response ? '재생 목록에 추가되었습니다.' : '재생 목록에서 삭제되었습니다.');
    },
    /*
      해당 재생 목록의 음악들 불러오기 API

      > MainApi.getMusicList(playListId);
      > return -> MusicList
    */
    async requestMusicList(playListId) {
      // 현재 재생 목록이 아닌 경우 -> 상태 변화 필요없음
      if (this.$store.state.main.selectedPlayList.id !== playListId) {
        return;
      }
      const response = await MainApi.getMusicList(playListId);
      this.$store.commit('main/setMusicList', response.musicList);
    },
  }
}
</script>
