<template>
	<div class="music-wave-wrap">
		<span />
		<span />
		<span />
		<span />
		<span />
		<span />
		<span />
	</div>
</template>

<script>
import "./musicWave.scss";

export default {
  name: 'MusicWave',
}
</script>
