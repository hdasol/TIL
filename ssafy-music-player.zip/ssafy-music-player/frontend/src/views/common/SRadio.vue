<template>
  <div class="radio-wrap">
		<span>
			<span v-if="checked"/>
		</span>
    <p>{{ text }}</p>
  </div>
</template>

<script>

import "./sradio.scss"

export default {
  name: 's-radio',
  components: {
  },
  props: {
		text: String,
		checked: Boolean,
  },
  data() {
    return {
    }
  },
  methods: {
	}
}
</script>
