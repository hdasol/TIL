<template>
  <div class="toast-wrap">
    <p>{{ message }}</p>
  </div>
</template>

<script>

import "./stoast.scss"

export default {
  name: 's-toast',
  components: {
  },
  computed: {
    message() {
      return this.$store.state.toast.message;
    },
  },
  mounted() {
    setTimeout(() => {
      this.$store.commit('toast/showToast', '');
    }, 2000);
  },
}
</script>
