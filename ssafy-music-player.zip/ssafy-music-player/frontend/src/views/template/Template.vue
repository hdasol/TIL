<template>
  <div>
    <!-- 여기부터 코드 작성 -->
  </div>
</template>

<script>
// import "./template.scss";

export default {
  name: 'Template',
  components: {
  },
  // : props
  props: {
  },
  // : data
  data() {
    return {
    }
  },
  // : computed
  computed: {
  },
  // : lifecycle hook
  mounted() {
  },
  // : methods
  methods: {
  }
}
</script>
