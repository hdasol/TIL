<template>
  <div>
    <!-- 여기부터 코드 작성 -->

    <!-- 샘플 코드 지우고 사용 -->
    <input v-model="msg">
    <p>prop: {{propMessage}}</p>
    <p>msg: {{msg}}</p>
    <p>helloMsg: {{helloMsg}}</p>
    <p>computed msg: {{computedMsg}}</p>
    <button @click="greet">Greet</button>
    <!-- 샘플 코드 지우고 사용 -->
  </div>
</template>

<script>
// import SButton from '@/views/common/SButton.vue'

export default {
  name: 'ExampleMain',
  components: {
    // SButton
  },
  // : props
  props: {
    propMessage : String,
  },
  // : data
  data() {
    return {
      helloMsg : 'Hello'
    }
  },
  // : computed
  computed: {
    computedMsg() {
      return 'computed ' + this.helloMsg
    }
  },
  // : lifecycle hook
  mounted() {
    this.greet();
  },
  methods: {
    greet() {

    }
  }
}
</script>
