<template>
  <div>
    <div class='gradient-box'></div>
  </div>
</template>

<script>
import "./gradient.scss";

export default {
  name: 'Gradient',
}
</script>
