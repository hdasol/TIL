<template>
  <div class="ripple-wrap" ref="rippleWrap">
    <div class="ripple" style="animation-delay: 0s"></div>
    <!-- vuex 상태 변화 감지 위한 코드 (기능 없음) -->
		<div v-if="musicColor" />
  </div>
</template>

<script>
import "./ripple.scss";

export default {
  name: 'Ripple',
	mounted() {
    this.onchangeColor(this.musicColor);
	},
  computed: {
    musicColor() {
			this.onchangeColor(this.$store.state.main.musicColor.hex);
      return this.$store.state.main.musicColor.hex;
    },
  },
  methods: {
		onchangeColor(c) {
			if (this.$refs.rippleWrap) {
				this.$refs.rippleWrap.style.backgroundColor = c
			}
		}
  }
}
</script>
