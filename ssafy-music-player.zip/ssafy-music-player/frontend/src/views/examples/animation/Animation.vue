<template>
  <div class="animation-wrap">
    <!-- Animations -->
    <sky v-if="selectedNum === 0" />
    <wave v-if="selectedNum === 1" />
    <ripple v-if="selectedNum === 2" />
    <gradient v-if="selectedNum === 3" />
    <My v-if="selectedNum === 4" />
    
    <!-- Selector -->
    <ul class="animation-selector">
      <li :class="{sel : selectedNum === 0}" @click="onSelect(0)">Sky</li>
      <li :class="{sel : selectedNum === 1}" @click="onSelect(1)">Wave</li>
      <li :class="{sel : selectedNum === 2}" @click="onSelect(2)">Ripple</li>
      <li :class="{sel : selectedNum === 3}" @click="onSelect(3)">Gradient</li>
      <li :class="{sel : selectedNum === 4}" @click="onSelect(4)">My</li>
    </ul>
  </div>
</template>

<script>
import "./animation.scss";
import Ripple from './ripple/Ripple.vue';
import Sky from './sky/Sky.vue';
import Wave from './wave/Wave.vue';
import Gradient from './gradient/Gradient.vue';
import My from './my/지역_0반_이지우.vue';

export default {
  name: 'Animation',
  components: {
    Sky,
    Wave,
    Ripple,
    Gradient,
    My,
  },
  data() {
    return {
      selectedNum : 0,
    }
  },
  methods: {
    onSelect(num) {
      this.selectedNum = num;
    }
  }
}
</script>
