<template>
  <div>
    <div class='my-animation'></div>
  </div>
</template>

<script>
import "./지역_0반_이지우.scss";

export default {
}
</script>
