<template>
  <div>
    <!-- 왼쪽 파도 -->
    <div class='wave-wrap' ref="waveBg1">
      <div class='wave -left'></div>
      <div class='wave -left -two'></div>
      <div class='wave -left -three'></div>
    </div>
    <!-- 오른쪽 파도 -->
    <div class='wave-wrap'  :style="{left: '50%', backgroundColor: '#fff'}">
      <div class='wave -right' ref="waveBg2"></div>
      <div class='wave -right -two' ref="waveBg3"></div>
      <div class='wave -right -three' ref="waveBg4"></div>
      <div class='wave-wrap'  :style="{width: '100%', left: '0', backgroundColor: musicColor, opacity: 0.7}"></div>
    </div>
  </div>
</template>

<script>
import "./wave.scss";

export default {
  name: 'Wave',
  computed: {
    musicColor() {
			this.onchangeColor(this.$store.state.main.musicColor.hex);
      return this.$store.state.main.musicColor.hex;
    },
  },
  mounted() {
    this.onchangeColor(this.musicColor);
  },
  methods: {
		onchangeColor(c) {
      // 색상 반전
			if (this.$refs.waveBg1) {
				this.$refs.waveBg1.style.backgroundColor = c
				this.$refs.waveBg2.style.backgroundColor = c
				this.$refs.waveBg3.style.backgroundColor = c
				this.$refs.waveBg4.style.backgroundColor = c
			}
		}
  }
}
</script>
