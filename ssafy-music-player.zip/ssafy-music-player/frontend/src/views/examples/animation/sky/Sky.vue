<template>
  <div>
    <div class="sky">
			<div class="sky-left"></div>
			<div class="sky-right"></div>
		</div>
    <div class="sun"></div>
    <div class="moon"></div>
    <div class="earth"></div>
  </div>
</template>

<script>
import "./sky.scss";

export default {
  name: 'Sky',
}
</script>
