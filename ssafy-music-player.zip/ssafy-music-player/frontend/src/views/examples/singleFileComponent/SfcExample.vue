<template>
  <div class="sfc-wrap">
    <div class="sfc-container">
      <!-- Input Test -->
      <input v-model="msg">
      
      <!-- Props -->
      <p>prop: {{propMessage}}</p>
      
      <p>msg: {{msg}}</p>

      <p>helloMsg: {{helloMsg}}</p>

      <p>computed msg: {{computedMsg}}</p>

      <button @click="increment">Greet</button>
      
      <p>computed count: {{computedVuexCount}}</p>
      <p>data count: {{dataCount}}</p>

      <s-radio :checked="true" text="예제" />
      <s-radio :checked="false" text="예제" />
      <s-radio :checked="false" text="예제" />
    </div>
  </div>
</template>

<script>
import './sfcExamples.scss'
import SRadio from '../../common/SRadio.vue'

// Single File Component Example
export default {
  name: 'SfcExample',
  components: {
    SRadio,
  },
  // : props
  props: {
    propMessage : String,
  },
  // : data
  data() {
    return {
      msg : 123,
      helloMsg : 'Hello ',
      dataCount : 0,
    }
  },
  // : computed
  computed: {
    computedMsg() {
      return 'computed ' + this.msg
    },
    computedVuexCount() {
      return this.$store.state.examples.count;
    }
  },
  // : lifecycle hook
  mounted() {
    this.greet();
  },
  methods: {
    greet() {
    },
    increment() {
      this.dataCount += 1;
      this.$store.commit('increment');
    }
  }
}
</script>
