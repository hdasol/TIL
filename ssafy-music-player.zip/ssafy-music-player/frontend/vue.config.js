// vue.config.js
module.exports = {
  productionSourceMap: false,
  outputDir: '../backend/src/main/resources/static'
}