<template>
  <div>
    <h5>{{ post.id }}</h5>
    <p>{{ post.image }}</p>
    <p>{{ post.title }}</p>
    <p>{{ post.id }}</p>
    <router-link
      :to="{ name:'PostDetail', params: { id:post.id }}">
      리뷰글로 이동하기
    </router-link>    
  </div>
</template>

<script>
export default {
  name: 'PostListItem',
  props: {
    post:Object,
  }

}
</script>

<style>

</style>