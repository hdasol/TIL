<template>
  <div>
    <h3>리뷰 리스트</h3>
    <PostListIte
      v-for="post in posts"
      :key="post.id"
      :post="post"/>

  </div>
</template>

<script>
import PostListItem from '@/components/PostListItem'

export default {
  name: 'PostList',
  components: {
    PostListItem,
  },
  computed: {
    posts() {
      return this.$store.state.posts
    }
  }
}
</script>

<style>

</style>