<template>
  <div>
    <h1>여기가 리뷰 게시판</h1>
    <hr>
    <PostList/>
  </div>
</template>

<script>
import PostList from '@/components/PostList'

export default {
  name: 'PostView',
  components: {
    PostList,
  },
}
</script>

<style>

</style>