<template>
  <div>
    <h1>여기는 프로필 페이지</h1>
  </div>
</template>

<script>
export default {
  name: 'MyProfile',

}
</script>

<style>

</style>