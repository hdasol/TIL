<template>
  <div>
    <h1>여기는 영화 전체 리스트</h1>
  </div>
</template>

<script>
export default {
  name: 'MovieList',

}
</script>

<style>

</style>