<template>
  <div>
    <h1>여기는 추천 페이지</h1>
  </div>
</template>

<script>
export default {
  name: 'RecommendView',

}
</script>

<style>

</style>