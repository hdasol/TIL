<template>
  <div>
    <h1>여기는 검색창</h1>
  </div>
</template>

<script>
export default {
  name: 'SearchView',

}
</script>

<style>

</style>