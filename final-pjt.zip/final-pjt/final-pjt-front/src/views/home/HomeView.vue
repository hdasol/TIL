<template>
  <div>
    <h1>여기가 메인 페이지</h1>
    <li v-for="post in posts" :key="post.id">{{ post.title }}</li>


  </div>
</template>

<script>

export default {
  name: "HomeView",
  mounted() {
    this.$store.dispatch("getPosts")
  },
  computed: {
    // store에서 posts 객체를 가지고 오자
    posts() {
      return this.$store.state.posts
    }
  }
}
</script>

<style>

</style>