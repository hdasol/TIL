import Vue from 'vue'
import VueRouter from 'vue-router'
import HomeView from '@/views/home/HomeView'
import MovieList from '@/views/home/MovieList'
import RecommendView from '@/views/home/RecommendView'
import MyProfile from '@/views/accounts/MyProfile'
import SearchView from '@/views/home/SearchView'
import Login from '@/views/accounts/Login'
import PostView from '@/views/community/PostView'
import SignUp from '@/views/accounts/SignUp'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/movielist',
    name: 'movielist',
    component: MovieList
  },
  {
    path: '/recommend',
    name: 'recommend',
    component: RecommendView
  },
  {
    path: '/profile',
    name: 'profile',
    component: MyProfile
  },
  {
    path: '/search',
    name: 'search',
    component: SearchView
  },
  {
    path: '/login',
    name: 'login',
    component: Login
  },
  {
    path: '/postview',
    name: 'postview',
    component: PostView
  },
  {
    path: '/signup',
    name: 'signup',
    component: SignUp
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
