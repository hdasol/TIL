<template>
  <div id="app">
    <nav>
      <router-link :to="{ name:'postview' }">리뷰게시판</router-link> |
      <router-link :to="{ name: 'home' }">메인</router-link> |
      <router-link :to="{ name: 'recommend' }">영화추천</router-link> |
      <router-link :to="{ name: 'search' }">검색</router-link> |
      <!-- 여기서 isLogin이 true면 프로필 사진이 뜨게 만들고, false면 login이 뜨게한다 -->
      <router-link :to="{ name: 'login' }">시작하기</router-link> 
      

    </nav>
    <router-view/>
  </div>
</template>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
